import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailsComponent } from './details/details.component';
import { OIAcadamyComponent } from './oiacadamy/oiacadamy.component';

const routes: Routes = [
  { path: 'details', component: DetailsComponent },
  { path: 'home', component: OIAcadamyComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: OIAcadamyComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

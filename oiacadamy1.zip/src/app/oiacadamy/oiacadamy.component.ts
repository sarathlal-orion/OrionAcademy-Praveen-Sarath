import { Component } from '@angular/core';

@Component({
  selector: 'app-oiacadamy',
  templateUrl: './oiacadamy.component.html',
  styleUrls: ['./oiacadamy.component.scss']
})
export class OIAcadamyComponent {

}
